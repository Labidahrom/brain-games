"""This init file makes welcome module."""
